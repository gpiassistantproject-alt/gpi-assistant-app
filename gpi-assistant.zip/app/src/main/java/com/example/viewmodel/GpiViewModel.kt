package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DemoData
import com.example.data.local.AppDatabase
import com.example.data.local.AttendanceEntity
import com.example.data.local.NoteEntity
import com.example.data.local.ProfileEntity
import com.example.data.remote.GeminiClient
import com.example.model.AppLanguage
import com.example.model.ChatMessage
import com.example.model.Department
import com.example.model.ScreenRoute
import com.example.model.Shift
import com.example.model.StudentProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GpiViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val noteDao = db.noteDao()
    private val attendanceDao = db.attendanceDao()
    private val profileDao = db.profileDao()

    // Navigation state
    private val _currentRoute = MutableStateFlow(ScreenRoute.HOME)
    val currentRoute: StateFlow<ScreenRoute> = _currentRoute.asStateFlow()

    private val navigationHistory = mutableListOf<ScreenRoute>()

    // Language state
    private val _language = MutableStateFlow(AppLanguage.BANGLA)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    // Student Profile state
    private val _profile = MutableStateFlow(
        StudentProfile(
            name = "মোঃ সাজিদ হাসান",
            rollNo = "612345",
            regNo = "1502398471",
            department = Department.COMPUTER,
            semester = 6,
            shift = Shift.FIRST,
            session = "2021-2022",
            bloodGroup = "B+",
            phone = "+880 1712-345678",
            email = "sajid.gpi.student@gmail.com"
        )
    )
    val profile: StateFlow<StudentProfile> = _profile.asStateFlow()

    // Room Persistent Notes
    val notes: StateFlow<List<NoteEntity>> = noteDao.getAllNotes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Room Persistent Attendance
    val attendanceList: StateFlow<List<AttendanceEntity>> = attendanceDao.getAllAttendance()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Tutor Chat State
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                text = "আসসালামু আলাইকুম! আমি GPI Assistant — গোপালগঞ্জ পলিটেকনিকের এআই টিউটর।\n\nডিপ্লোমা ইন ইঞ্জিনিয়ারিং যেকোনো বিষয়ের নোট, কোডিং, সার্কিট, সমীকরণ বা বোর্ড পরীক্ষার প্রস্তুতি নিয়ে আমাকে প্রশ্ন করতে পারো।",
                isUser = false
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    // Filters for screens
    val selectedDepartment = MutableStateFlow(Department.COMPUTER)
    val selectedSemester = MutableStateFlow(6)
    val selectedShift = MutableStateFlow(Shift.FIRST)

    init {
        // Populate initial sample data in Room if empty
        viewModelScope.launch {
            noteDao.getAllNotes().collect { currentNotes ->
                if (currentNotes.isEmpty()) {
                    DemoData.sampleLectureNotes.forEach { (title, content, tag) ->
                        noteDao.insertNote(
                            NoteEntity(
                                title = title,
                                content = content,
                                subjectTag = tag,
                                semester = 6,
                                isPinned = false
                            )
                        )
                    }
                }
            }
        }

        viewModelScope.launch {
            attendanceDao.getAllAttendance().collect { currentAtt ->
                if (currentAtt.isEmpty()) {
                    val defaultSubjects = listOf(
                        Triple("66661", "Database Application", 24 to 28),
                        Triple("66662", "Web Development", 26 to 28),
                        Triple("66663", "Data Communication", 21 to 28),
                        Triple("66664", "Microcontroller & Embedded", 25 to 28),
                        Triple("66867", "Industrial Management", 20 to 28)
                    )
                    defaultSubjects.forEach { (code, name, counts) ->
                        attendanceDao.insertAttendance(
                            AttendanceEntity(
                                subjectCode = code,
                                subjectName = name,
                                attendedClasses = counts.first,
                                totalClasses = counts.second
                            )
                        )
                    }
                }
            }
        }
    }

    fun navigateTo(route: ScreenRoute) {
        if (_currentRoute.value != route) {
            navigationHistory.add(_currentRoute.value)
            _currentRoute.value = route
        }
    }

    fun navigateBack(): Boolean {
        if (navigationHistory.isNotEmpty()) {
            val previous = navigationHistory.removeAt(navigationHistory.lastIndex)
            _currentRoute.value = previous
            return true
        } else if (_currentRoute.value != ScreenRoute.HOME) {
            _currentRoute.value = ScreenRoute.HOME
            return true
        }
        return false
    }

    fun toggleLanguage() {
        _language.value = if (_language.value == AppLanguage.BANGLA) AppLanguage.ENGLISH else AppLanguage.BANGLA
    }

    fun updateProfile(updated: StudentProfile) {
        _profile.value = updated
        viewModelScope.launch {
            profileDao.saveProfile(
                ProfileEntity(
                    name = updated.name,
                    rollNo = updated.rollNo,
                    regNo = updated.regNo,
                    departmentCode = updated.department.code,
                    semester = updated.semester,
                    shiftCode = updated.shift.code,
                    session = updated.session,
                    bloodGroup = updated.bloodGroup,
                    phone = updated.phone,
                    email = updated.email
                )
            )
        }
    }

    // AI Tutor message
    fun sendAiPrompt(promptText: String) {
        if (promptText.isBlank() || _isAiLoading.value) return

        val userMsg = ChatMessage(text = promptText, isUser = true)
        _chatMessages.value = _chatMessages.value + userMsg
        _isAiLoading.value = true

        viewModelScope.launch {
            val history = _chatMessages.value.map { it.text to it.isUser }
            val answer = GeminiClient.askTutor(promptText, history)
            val aiMsg = ChatMessage(text = answer, isUser = false)
            _chatMessages.value = _chatMessages.value + aiMsg
            _isAiLoading.value = false
        }
    }

    fun clearAiChat() {
        _chatMessages.value = listOf(
            ChatMessage(
                text = "চ্যাট ক্লিয়ার করা হয়েছে। আপনার নতুন কোনো প্রশ্ন থাকলে লিখুন।",
                isUser = false
            )
        )
    }

    // Notes management
    fun addNote(title: String, content: String, tag: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            noteDao.insertNote(
                NoteEntity(
                    title = title,
                    content = content,
                    subjectTag = if (tag.isBlank()) "General" else tag,
                    semester = _profile.value.semester
                )
            )
        }
    }

    fun deleteNote(id: Int) {
        viewModelScope.launch {
            noteDao.deleteNoteById(id)
        }
    }

    fun togglePinNote(note: NoteEntity) {
        viewModelScope.launch {
            noteDao.updateNote(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
        }
    }

    // Attendance management
    fun logAttendance(entity: AttendanceEntity, isPresent: Boolean) {
        viewModelScope.launch {
            val newTotal = entity.totalClasses + 1
            val newAttended = if (isPresent) entity.attendedClasses + 1 else entity.attendedClasses
            attendanceDao.updateAttendance(
                entity.copy(
                    attendedClasses = newAttended,
                    totalClasses = newTotal,
                    lastUpdated = System.currentTimeMillis()
                )
            )
        }
    }

    fun resetAttendance(entity: AttendanceEntity) {
        viewModelScope.launch {
            attendanceDao.updateAttendance(
                entity.copy(
                    attendedClasses = 0,
                    totalClasses = 0,
                    lastUpdated = System.currentTimeMillis()
                )
            )
        }
    }

    fun addSubjectAttendance(code: String, name: String) {
        if (code.isBlank() || name.isBlank()) return
        viewModelScope.launch {
            attendanceDao.insertAttendance(
                AttendanceEntity(
                    subjectCode = code,
                    subjectName = name,
                    attendedClasses = 0,
                    totalClasses = 0
                )
            )
        }
    }

    fun deleteAttendanceSubject(id: Int) {
        viewModelScope.launch {
            attendanceDao.deleteAttendanceById(id)
        }
    }
}
