package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Bloodtype
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoData
import com.example.model.AppLanguage
import com.example.model.Department
import com.example.model.Shift
import com.example.model.StudentProfile
import com.example.ui.components.DemoDisclaimerBanner
import com.example.ui.theme.EmeraldGreenDark
import com.example.ui.theme.EmeraldGreenPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    profile: StudentProfile,
    language: AppLanguage,
    onUpdateProfile: (StudentProfile) -> Unit
) {
    val isBn = language == AppLanguage.BANGLA
    var showEditDialog by remember { mutableStateOf(false) }

    var editName by remember { mutableStateOf(profile.name) }
    var editRoll by remember { mutableStateOf(profile.rollNo) }
    var editReg by remember { mutableStateOf(profile.regNo) }
    var editDept by remember { mutableStateOf(profile.department) }
    var editSemester by remember { mutableIntStateOf(profile.semester) }
    var editShift by remember { mutableStateOf(profile.shift) }
    var editSession by remember { mutableStateOf(profile.session) }
    var editBlood by remember { mutableStateOf(profile.bloodGroup) }
    var editPhone by remember { mutableStateOf(profile.phone) }
    var editEmail by remember { mutableStateOf(profile.email) }

    var deptMenuExpanded by remember { mutableStateOf(false) }
    var shiftMenuExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Digital Student ID Card
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = EmeraldGreenDark,
                shadowElevation = 3.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_student_id_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = "GPI",
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isBn) "গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউট" else "Gopalganj Polytechnic Institute",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = Color(0xFF6EE7B7),
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "STUDENT IDENTITY CARD",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White.copy(alpha = 0.7f),
                                    letterSpacing = 1.sp
                                )
                            )
                        }

                        IconButton(
                            onClick = {
                                editName = profile.name
                                editRoll = profile.rollNo
                                editReg = profile.regNo
                                editDept = profile.department
                                editSemester = profile.semester
                                editShift = profile.shift
                                editSession = profile.session
                                editBlood = profile.bloodGroup
                                editPhone = profile.phone
                                editEmail = profile.email
                                showEditDialog = true
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape)
                                .testTag("edit_profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Profile",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = profile.name,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "${if (isBn) profile.department.nameBn else profile.department.nameEn} • ${if (isBn) "${profile.semester}ষ্ঠ পর্ব" else "Sem ${profile.semester}"} • ${if (isBn) profile.shift.nameBn else profile.shift.nameEn}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color(0xFFD1FAE5),
                            fontWeight = FontWeight.SemiBold
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Roll, Reg, Session row
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text("রোল নং", style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.7f)))
                            Text(profile.rollNo, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        }
                        Column {
                            Text("রেজিস্ট্রেশন", style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.7f)))
                            Text(profile.regNo, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        }
                        Column {
                            Text("সেশন", style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.7f)))
                            Text(profile.session, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                        }
                        Column {
                            Text("রক্তের গ্রুপ", style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.7f)))
                            Text(profile.bloodGroup, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFFFCA5A5)))
                        }
                    }
                }
            }
        }

        // Contact Info Card
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isBn) "যোগাযোগের তথ্য" else "Contact Information",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = EmeraldGreenPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = profile.phone, style = MaterialTheme.typography.bodyMedium)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = EmeraldGreenPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = profile.email, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        // About Gopalganj Polytechnic Institute
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.School, contentDescription = null, tint = EmeraldGreenPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBn) "গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউট পরিচিতি" else "About Gopalganj Polytechnic Institute",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isBn) DemoData.ABOUT_GPI_BN else DemoData.ABOUT_GPI_EN,
                        style = MaterialTheme.typography.bodySmall.copy(
                            lineHeight = 19.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "চন্দ্রিমা রোড, ঘোনাপাড়া, গোপালগঞ্জ-৮১০০",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFB45309), fontWeight = FontWeight.SemiBold)
                        )
                    }
                }
            }
        }

        // App Vision & Creator Card
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFF0FDF4),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = Color(0xFF15803D))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBn) "GPI Assistant উদ্যোগ ও লক্ষ্য" else "About GPI Assistant",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isBn) {
                            "এই অ্যাপ্লিকেশনটি গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউটের এক শিক্ষার্থী তৈরি করেছেন। এটি ডিপ্লোমা ইন ইঞ্জিনিয়ারিং শিক্ষার্থীদের পড়ালেখা, রুটিন, সিলেবাস, এআই টিউটরিং এবং সিজিপিএ গণনার জন্য একটি আধুনিক প্ল্যাটফর্ম হিসেবে গড়ে তোলা হচ্ছে। ভবিষ্যতে বাংলাদেশের সকল সরকারি ও বেসরকারি পলিটেকনিকের শিক্ষার্থীদের সহযোগিতা করার লক্ষ্য রয়েছে।"
                        } else {
                            "Created by a student of Gopalganj Polytechnic Institute. Built as an AI academic assistant, routine planner, syllabus guide, and CGPA manager to support polytechnic students across Bangladesh."
                        },
                        style = MaterialTheme.typography.bodySmall.copy(
                            lineHeight = 18.sp,
                            color = Color(0xFF166534)
                        )
                    )
                }
            }
        }

        item {
            DemoDisclaimerBanner(language = language)
        }
    }

    // Edit Profile Dialog
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = {
                Text(
                    text = if (isBn) "শিক্ষার্থী তথ্য হালনাগাদ" else "Edit Student Profile",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text(if (isBn) "নাম" else "Full Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editRoll,
                            onValueChange = { editRoll = it },
                            label = { Text(if (isBn) "রোল নং" else "Roll No") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = editReg,
                            onValueChange = { editReg = it },
                            label = { Text(if (isBn) "রেজি নং" else "Reg No") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editSemester.toString(),
                            onValueChange = { editSemester = it.toIntOrNull() ?: editSemester },
                            label = { Text(if (isBn) "পর্ব (১-৮)" else "Semester (1-8)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = editSession,
                            onValueChange = { editSession = it },
                            label = { Text(if (isBn) "সেশন" else "Session") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = editBlood,
                        onValueChange = { editBlood = it },
                        label = { Text(if (isBn) "রক্তের গ্রুপ" else "Blood Group") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = { editPhone = it },
                        label = { Text(if (isBn) "ফোন নম্বর" else "Phone") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editEmail,
                        onValueChange = { editEmail = it },
                        label = { Text(if (isBn) "ইমেইল" else "Email") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateProfile(
                            profile.copy(
                                name = editName.trim(),
                                rollNo = editRoll.trim(),
                                regNo = editReg.trim(),
                                department = editDept,
                                semester = editSemester.coerceIn(1, 8),
                                shift = editShift,
                                session = editSession.trim(),
                                bloodGroup = editBlood.trim(),
                                phone = editPhone.trim(),
                                email = editEmail.trim()
                            )
                        )
                        showEditDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary)
                ) {
                    Text(if (isBn) "সংরক্ষণ করুন" else "Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text(if (isBn) "বাতিল" else "Cancel")
                }
            }
        )
    }
}
