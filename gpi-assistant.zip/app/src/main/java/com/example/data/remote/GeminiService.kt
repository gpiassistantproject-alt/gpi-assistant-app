package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "role") val role: String? = null,
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent?
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>?
)

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    private val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApi::class.java)
    }

    private val systemPrompt = """
        You are "GPI Assistant" (জিপিআই অ্যাসিস্ট্যান্ট), an intelligent, friendly AI academic tutor and polytechnic student guide created by a student of Gopalganj Polytechnic Institute (গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউট - GPI) to help polytechnic and diploma engineering students across Bangladesh.
        
        Key Guidelines:
        1. You are fluent in Bangla and English. Prefer explaining in clear, engaging Bengali (বাংলা) by default or match the language used by the student.
        2. Help with BTEB (Bangladesh Technical Education Board) Diploma in Engineering subjects across all departments (Computer/CST, Civil, Electrical, Mechanical, Electronics, RAC, AIDT, Telecommunication).
        3. Clarify concepts, solve technical equations, provide code snippets (C, Java, Python, PHP, JavaScript, SQL, HTML/CSS, 8051 Assembly, Embedded C), explain circuit diagrams and mechanical/civil concepts with step-by-step clarity.
        4. Give practical exam tips, BTEB question format guidance (Short questions, Brief questions, Broad questions with marks 1, 2, 8/10), and study advice.
        5. Maintain a polite, encouraging, and respectful tone for Bangladeshi polytechnic learners.
    """.trimIndent()

    suspend fun askTutor(userPrompt: String, history: List<Pair<String, Boolean>> = emptyList()): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউট (GPI) এআই টিউটর অফলাইন মোড:\n\nআপনার প্রশ্ন: \"$userPrompt\"\n\n(এআই রেসপন্সের জন্য এআই স্টুডিও সিক্রেট প্যানেলে GEMINI_API_KEY সেট করুন।)\n\nটিপস: বিটিইবি সেমিস্টার পরীক্ষার জন্য প্রিভিয়াস ইয়ারের বোর্ড প্রশ্ন এবং ব্যবহারিক ল্যাব পরীক্ষা নিয়মিত অনুশীলন করুন।"
        }

        try {
            val contents = mutableListOf<GeminiContent>()
            // Add conversation context
            for ((msgText, isUser) in history.takeLast(6)) {
                contents.add(
                    GeminiContent(
                        role = if (isUser) "user" else "model",
                        parts = listOf(GeminiPart(text = msgText))
                    )
                )
            }
            contents.add(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = userPrompt))
                )
            )

            val request = GeminiRequest(
                contents = contents,
                systemInstruction = GeminiContent(
                    parts = listOf(GeminiPart(text = systemPrompt))
                )
            )

            val response = api.generateContent(apiKey, request)
            val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            reply ?: "দুঃখিত, কোনো উত্তর পাওয়া যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।"
        } catch (e: Exception) {
            Log.e(TAG, "Gemini API Error", e)
            "নেটওয়ার্ক বা এপিআই সংক্রান্ত সমস্যা হয়েছে: ${e.localizedMessage ?: e.message}\n\nঅনুগ্রহ করে ইন্টারনেট সংযোগ চেক করে পুনরায় চেষ্টা করুন।"
        }
    }
}
