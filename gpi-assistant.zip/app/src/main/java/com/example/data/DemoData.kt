package com.example.data

import com.example.model.ClassRoutineItem
import com.example.model.Department
import com.example.model.ExamRoutineItem
import com.example.model.NoticeItem
import com.example.model.Shift
import com.example.model.SyllabusSubject

object DemoData {

    const val DISCLAIMER_BN = "সতর্কতা: এটি গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউটের ডেমো ডেটা। অফিসিয়াল নোটিশ ও রুটিনের জন্য ক্যাম্পাসের নোটিশ বোর্ড অনুসরণ করুন।"
    const val DISCLAIMER_EN = "Disclaimer: This is demo data for Gopalganj Polytechnic Institute. For official routines and notices, please follow the institute campus board."

    const val ABOUT_GPI_BN = "গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউট (GPI) গণপ্রজাতন্ত্রী বাংলাদেশ সরকারের কারিগরি ও মাদ্রাসা শিক্ষা বিভাগ এবং কারিগরি শিক্ষা অধিদপ্তরের (DTE) অধীনস্থ একটি স্বনামধন্য সরকারি ইঞ্জিনিয়ারিং শিক্ষা প্রতিষ্ঠান। ২০০১ সালে প্রতিষ্ঠিত এই ক্যাম্পাসে কম্পিউটার, সিভিল, ইলেকট্রিক্যাল, ইলেকট্রনিক্স, মেকানিক্যাল ও আরএসি সহ বিভিন্ন টেকনোলজিতে ৪ বছর মেয়াদী ডিপ্লোমা ইন ইঞ্জিনিয়ারিং কোর্স পরিচালিত হয়।"
    const val ABOUT_GPI_EN = "Gopalganj Polytechnic Institute (GPI) is a leading public technical polytechnic institute in Bangladesh under the Directorate of Technical Education (DTE) and BTEB. Established in 2001, it offers 4-year Diploma in Engineering courses across multiple disciplines with modern workshop and lab facilities."


    val notices = listOf(
        NoticeItem(
            id = "n1",
            titleEn = "BTEB Diploma 6th & 8th Semester Final Exam Form Fill-up 2026",
            titleBn = "বিটিইবি ডিপ্লোমা ৬ষ্ঠ ও ৮ম পর্ব সমাপনী পরীক্ষা ফরম ফিলাপ ২০২৬",
            categoryEn = "Form Fillup",
            categoryBn = "ফরম ফিলাপ",
            dateEn = "Aug 12, 2026",
            dateBn = "১২ আগস্ট, ২০২৬",
            contentEn = "Diploma in Engineering 6th and 8th semester students are requested to complete online form fill-up with late fee payment by August 28, 2026 through the college portal.",
            contentBn = "ডিপ্লোমা ইন ইঞ্জিনিয়ারিং ৬ষ্ঠ ও ৮ম পর্বের শিক্ষার্থীদের আগামী ২৮ আগস্ট ২০২৬ তারিখের মধ্যে নির্ধারিত ফি প্রদান করে অনলাইন ফরম ফিলাপ সম্পন্ন করার জন্য বলা হচ্ছে।",
            isUrgent = true
        ),
        NoticeItem(
            id = "n2",
            titleEn = "Mid-Term Examination Routine Published - Autumn 2026",
            titleBn = "সকল টেকনোলজির মিড-টার্ম পরীক্ষার সময়সূচি প্রকাশ - ২০২৬",
            categoryEn = "Examination",
            categoryBn = "পরীক্ষা",
            dateEn = "Aug 10, 2026",
            dateBn = "১০ আগস্ট, ২০২৬",
            contentEn = "Mid-term exams for all departments (CST, Civil, Electrical, Mechanical, Electronics, RAC) will commence from September 05, 2026. Detailed room routine is on notice board.",
            contentBn = "সকল বিভাগের (কম্পিউটার, সিভিল, ইলেকট্রিক্যাল, মেকানিক্যাল, ইলেকট্রনিক্স, আরএসি) মিড-টার্ম পরীক্ষা আগামী ৫ সেপ্টেম্বর ২০২৬ থেকে শুরু হবে। বিস্তারিত রুটিন নিম্নে সংযুক্ত।",
            isUrgent = true
        ),
        NoticeItem(
            id = "n3",
            titleEn = "Government Technical Stipend (Upobritta) Disbursement Update",
            titleBn = "কারিগরি শিক্ষা অধিদপ্তরের উপবৃত্তি সংক্রান্ত জরুরি তথ্য",
            categoryEn = "Scholarship",
            categoryBn = "উপবৃত্তি",
            dateEn = "Aug 06, 2026",
            dateBn = "০৬ আগস্ট, ২০২৬",
            contentEn = "Eligible female and selected male students are requested to verify their active Nagad/bKash mobile banking numbers in the student affairs section.",
            contentBn = "কারিগরি উপবৃত্তির তালিকাভুক্ত ছাত্র-ছাত্রীদের সক্রিয় নগদ/বিকাশ অ্যাকাউন্ট নাম্বার আগামী ২০ আগস্টের মধ্যে একাডেমিক শাখায় যাচাই করার নির্দেশ দেয়া হলো।",
            isUrgent = false
        ),
        NoticeItem(
            id = "n4",
            titleEn = "Annual Technical Project Fair & Robotics Olympiad 2026",
            titleBn = "বার্ষিক বিজ্ঞান ও প্রজেক্ট ফেয়ার এবং রোবোটিক্স অলিম্পিয়াড ২০২৬",
            categoryEn = "Events",
            categoryBn = "ইভেন্ট ও ক্লাব",
            dateEn = "Jul 28, 2026",
            dateBn = "২৮ জুলাই, ২০২৬",
            contentEn = "GPI Robotics & Innovation Club invites all departments to register technical capstone projects for the upcoming district level polytechnic symposium.",
            contentBn = "জিপিআই রোবোটিক্স ক্লাবের উদ্যোগে আগামী সেপ্টেম্বর মাসে অনুষ্ঠিতব্য ইনোভেশন ফেয়ারে প্রজেক্ট জমাদানের আহবান জানানো হচ্ছে। আকর্ষণীয় পুরস্কারের ব্যবস্থা রয়েছে।",
            isUrgent = false
        ),
        NoticeItem(
            id = "n5",
            titleEn = "Mandatory 75% Class Attendance Requirement for Board Final",
            titleBn = "বোর্ড সমাপনী পরীক্ষায় অংশগ্রহণের জন্য নূন্যতম ৭৫% উপস্থিতি বাধ্যতামূলক",
            categoryEn = "Academic",
            categoryBn = "একাডেমিক",
            dateEn = "Jul 15, 2026",
            dateBn = "১৫ জুলাই, ২০২৬",
            contentEn = "As per BTEB regulations, students maintaining less than 75% attendance will not be permitted to register for the upcoming board examinations.",
            contentBn = "বাংলাদেশ কারিগরি শিক্ষা বোর্ডের প্রবিধান অনুযায়ী ৭৫% এর কম উপস্থিত শিক্ষার্থীদের পরীক্ষায় অংশগ্রহণের সুযোগ থাকবে না। প্রতিদিন ক্লাসে উপস্থিত থাকুন।",
            isUrgent = true
        )
    )

    val classRoutines = listOf(
        // Saturday - Computer 6th 1st shift
        ClassRoutineItem("cr1", "Saturday", "শনিবার", "08:00 AM - 08:45 AM", "66661", "Database Application", "ডাটাবেস অ্যাপ্লিকেশন", "Engr. Tanvir Ahmed", "ইঞ্জি. তানভীর আহমেদ", "Lab-201", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr2", "Saturday", "শনিবার", "08:45 AM - 09:30 AM", "66662", "Web Development & Design", "ওয়েব ডেভেলপমেন্ট", "Engr. Nusrat Jahan", "ইঞ্জি. নুসরাত জাহান", "Lab-202", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr3", "Saturday", "শনিবার", "09:30 AM - 10:15 AM", "66663", "Data Communication", "ডাটা কমিউনিকেশন", "Md. Rafiqul Islam", "মোঃ রফিকুল ইসলাম", "Room-304", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr4", "Saturday", "শনিবার", "10:30 AM - 12:00 PM", "66664", "Microcontroller & Embedded (Lab)", "মাইক্রোকন্ট্রোলার ল্যাব", "Engr. Sajid Mahmud", "ইঞ্জি. সাজিদ মাহমুদ", "HW Lab-1", Department.COMPUTER, 6, Shift.FIRST),

        // Sunday
        ClassRoutineItem("cr5", "Sunday", "রবিবার", "08:00 AM - 09:30 AM", "66665", "Software Engineering", "সফটওয়্যার ইঞ্জিনিয়ারিং", "Engr. Tanvir Ahmed", "ইঞ্জি. তানভীর আহমেদ", "Room-302", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr6", "Sunday", "রবিবার", "09:30 AM - 10:15 AM", "66867", "Industrial Management", "ইন্ডাস্ট্রিয়াল ম্যানেজমেন্ট", "A. K. Azad", "এ. কে. আজাদ", "Room-302", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr7", "Sunday", "রবিবার", "10:30 AM - 12:45 PM", "66661", "Database Practical Lab", "ডাটাবেস প্র্যাক্টিক্যাল", "Engr. Tanvir Ahmed", "ইঞ্জি. তানভীর আহমেদ", "Lab-201", Department.COMPUTER, 6, Shift.FIRST),

        // Monday
        ClassRoutineItem("cr8", "Monday", "সোমবার", "08:00 AM - 08:45 AM", "66663", "Data Communication", "ডাটা কমিউনিকেশন", "Md. Rafiqul Islam", "মোঃ রফিকুল ইসলাম", "Room-304", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr9", "Monday", "সোমবার", "08:45 AM - 10:15 AM", "66662", "Web Design Lab", "ওয়েব ডিজাইন ল্যাব", "Engr. Nusrat Jahan", "ইঞ্জি. নুসরাত জাহান", "Lab-202", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr10", "Monday", "সোমবার", "10:30 AM - 11:15 AM", "66664", "Microcontroller Theory", "মাইক্রোকন্ট্রোলার থিওরি", "Engr. Sajid Mahmud", "ইঞ্জি. সাজিদ মাহমুদ", "Room-304", Department.COMPUTER, 6, Shift.FIRST),

        // Tuesday
        ClassRoutineItem("cr11", "Tuesday", "মঙ্গলবার", "08:00 AM - 09:30 AM", "66665", "Software Testing & QA", "সফটওয়্যার কোয়ালিটি", "Engr. Tanvir Ahmed", "ইঞ্জি. তানভীর আহমেদ", "Lab-203", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr12", "Tuesday", "মঙ্গলবার", "09:30 AM - 10:15 AM", "66867", "Industrial Management", "ইন্ডাস্ট্রিয়াল ম্যানেজমেন্ট", "A. K. Azad", "এ. কে. আজাদ", "Room-302", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr13", "Tuesday", "মঙ্গলবার", "10:30 AM - 12:45 PM", "66666", "Network Administration Lab", "নেটওয়ার্ক ল্যাব", "Md. Kamal Hossain", "মোঃ কামাল হোসেন", "NetLab-4", Department.COMPUTER, 6, Shift.FIRST),

        // Wednesday
        ClassRoutineItem("cr14", "Wednesday", "বুধবার", "08:00 AM - 08:45 AM", "66662", "Web Development", "ওয়েব ডেভেলপমেন্ট", "Engr. Nusrat Jahan", "ইঞ্জি. নুসরাত জাহান", "Room-302", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr15", "Wednesday", "বুধবার", "08:45 AM - 09:30 AM", "66664", "Microcontroller & Sensors", "মাইক্রোকন্ট্রোলার", "Engr. Sajid Mahmud", "ইঞ্জি. সাজিদ মাহমুদ", "HW Lab-1", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr16", "Wednesday", "বুধবার", "09:30 AM - 11:00 AM", "66667", "Capstone Project Review", "ক্যাপস্টোন প্রজেক্ট", "Dept Faculty Panel", "শিক্ষক প্যানেল", "Auditorium", Department.COMPUTER, 6, Shift.FIRST),

        // Thursday
        ClassRoutineItem("cr17", "Thursday", "বৃহস্পতিবার", "08:00 AM - 09:30 AM", "66661", "Advance SQL & Queries", "অ্যাডভান্স এসকিউএল", "Engr. Tanvir Ahmed", "ইঞ্জি. তানভীর আহমেদ", "Lab-201", Department.COMPUTER, 6, Shift.FIRST),
        ClassRoutineItem("cr18", "Thursday", "বৃহস্পতিবার", "09:30 AM - 11:00 AM", "66663", "Telecom & Optical Fiber", "অপটিক্যাল ফাইবার নেটওয়ার্ক", "Md. Rafiqul Islam", "মোঃ রফিকুল ইসলাম", "Room-304", Department.COMPUTER, 6, Shift.FIRST)
    )

    val examRoutines = listOf(
        ExamRoutineItem("er1", "Sep 15, 2026", "১৫ সেপ্টেম্বর, ২০২৬", "Tuesday", "মঙ্গলবার", "10:00 AM - 01:00 PM", "Semester Final", "সেমিস্টার ফাইনাল", "66661", "Database Application", "ডাটাবেস অ্যাপ্লিকেশন", "Room 201-205", Department.COMPUTER, 6),
        ExamRoutineItem("er2", "Sep 18, 2026", "১৮ সেপ্টেম্বর, ২০২৬", "Friday", "শুক্রবার", "10:00 AM - 01:00 PM", "Semester Final", "সেমিস্টার ফাইনাল", "66662", "Web Development & Design", "ওয়েব ডেভেলপমেন্ট", "Room 201-205", Department.COMPUTER, 6),
        ExamRoutineItem("er3", "Sep 22, 2026", "২২ সেপ্টেম্বর, ২০২৬", "Tuesday", "মঙ্গলবার", "10:00 AM - 01:00 PM", "Semester Final", "সেমিস্টার ফাইনাল", "66663", "Data Communication", "ডাটা কমিউনিকেশন", "Room 301-306", Department.COMPUTER, 6),
        ExamRoutineItem("er4", "Sep 26, 2026", "২৬ সেপ্টেম্বর, ২০২৬", "Saturday", "শনিবার", "10:00 AM - 01:00 PM", "Semester Final", "সেমিস্টার ফাইনাল", "66664", "Microcontroller & Embedded", "মাইক্রোকন্ট্রোলার সিস্টেম", "Room 301-306", Department.COMPUTER, 6),
        ExamRoutineItem("er5", "Sep 30, 2026", "৩০ সেপ্টেম্বর, ২০২৬", "Wednesday", "বুধবার", "10:00 AM - 01:00 PM", "Semester Final", "সেমিস্টার ফাইনাল", "66867", "Industrial Management", "ইন্ডাস্ট্রিয়াল ম্যানেজমেন্ট", "Room 101-108", Department.COMPUTER, 6),
        ExamRoutineItem("er6", "Oct 05, 2026", "০৫ অক্টোবর, ২০২৬", "Monday", "সোমবার", "09:00 AM - 04:00 PM", "Board Practical", "বোর্ড প্র্যাক্টিক্যাল", "66661", "Database Application Practical", "ডাটাবেস ল্যাব পরীক্ষা", "Computer Lab 1-3", Department.COMPUTER, 6)
    )

    val syllabusSubjects = listOf(
        SyllabusSubject(
            code = "66661",
            nameEn = "Database Application",
            nameBn = "ডাটাবেস অ্যাপ্লিকেশন",
            credits = 4,
            theoryHours = 3,
            practicalHours = 3,
            department = Department.COMPUTER,
            semester = 6,
            descriptionEn = "Relational database concepts, SQL query optimization, ER diagrams, normalization (1NF-BCNF), indexing, triggers and stored procedures with MySQL/PostgreSQL.",
            descriptionBn = "রিলেশনাল ডাটাবেস ডিজাইন, এসকিউএল কোয়েরি, নরমালাইজেশন, ই-আর ডায়াগ্রাম, ইনডেক্সিং এবং ট্রানজেকশন ম্যানেজমেন্ট।",
            books = listOf("Database System Concepts by Silberschatz", "BTEB Approved Database Note Guide")
        ),
        SyllabusSubject(
            code = "66662",
            nameEn = "Web Development",
            nameBn = "ওয়েব ডেভেলপমেন্ট",
            credits = 4,
            theoryHours = 3,
            practicalHours = 3,
            department = Department.COMPUTER,
            semester = 6,
            descriptionEn = "Front-end & back-end web principles: HTML5, CSS3, JavaScript, PHP/Node.js, RESTful API consumption, session management and database connectivity.",
            descriptionBn = "ওয়েব প্রোগ্রামিং, এইচটিএমএল৫, সিএসএস৩, জাভাস্ক্রিপ্ট, পিএইচপি ও আধুনিক ফ্রেমওয়ার্ক ব্যাকএন্ড কানেক্টিভিটি।",
            books = listOf("Learning Web Design by Robbins", "BTEB Polytechnic Web Engineering")
        ),
        SyllabusSubject(
            code = "66663",
            nameEn = "Data Communication",
            nameBn = "ডাটা কমিউনিকেশন",
            credits = 3,
            theoryHours = 2,
            practicalHours = 3,
            department = Department.COMPUTER,
            semester = 6,
            descriptionEn = "Signal transmission, modulation techniques (AM/FM/QAM), OSI & TCP/IP model layers, multiplexing, error detection and optical fiber transmission.",
            descriptionBn = "সিগন্যাল ট্রান্সমিশন, মডুলেশন, টিসিপি/আইপি মডেল, মাল্টিপ্লেক্সিং এবং ফাইবার অপটিক্যাল কমিউনিকেশন টেকনোলজি।",
            books = listOf("Data Communications and Networking by Behrouz Forouzan")
        ),
        SyllabusSubject(
            code = "66664",
            nameEn = "Microcontroller & Embedded System",
            nameBn = "মাইক্রোকন্ট্রোলার ও এমবেডেড সিস্টেম",
            credits = 3,
            theoryHours = 2,
            practicalHours = 3,
            department = Department.COMPUTER,
            semester = 6,
            descriptionEn = "8051 and AVR/Arduino architecture, assembly and Embedded C programming, GPIO, timers, interrupts, ADC, sensor interfacing and IoT applications.",
            descriptionBn = "মাইক্রোকন্ট্রোলার আর্কিটেকচার, সি প্রোগ্রামিং, সেন্সর ইন্টারফেসিং, মোটর কন্ট্রোল ও আইওটি এমবেডেড প্রজেক্ট।",
            books = listOf("The 8051 Microcontroller and Embedded Systems by Mazidi")
        ),
        SyllabusSubject(
            code = "66867",
            nameEn = "Industrial Management",
            nameBn = "ইন্ডাস্ট্রিয়াল ম্যানেজমেন্ট",
            credits = 2,
            theoryHours = 2,
            practicalHours = 0,
            department = Department.COMPUTER,
            semester = 6,
            descriptionEn = "Principles of scientific management, industrial safety and labor law, plant location, production planning, quality control (TQM), ISO standards and inventory control.",
            descriptionBn = "ব্যবস্থাপনার মূলনীতি, শিল্প কারখানা নিরাপত্তা ও শ্রম আইন, প্রোডাকশন প্ল্যানিং, কোয়ালিটি কন্ট্রোল ও ইনভেন্টরি ম্যানেজমেন্ট।",
            books = listOf("Industrial Engineering & Management by O.P. Khanna")
        ),
        // Civil Subject Sample
        SyllabusSubject(
            code = "66461",
            nameEn = "Design of Structure - 1",
            nameBn = "ডিজাইন অফ স্ট্রাকচার - ১",
            credits = 4,
            theoryHours = 3,
            practicalHours = 3,
            department = Department.CIVIL,
            semester = 6,
            descriptionEn = "RCC beam analysis, shear stress calculations, bond and anchorage, slab design, WSD and USD methods.",
            descriptionBn = "আরসিসি বিম এনালাইসিস, শিয়ার স্ট্রেস হিসাব, রিইনফোর্সড স্ল্যাব ডিজাইন এবং ইউএসডি মেথড।",
            books = listOf("Design of Concrete Structures by Nilson")
        ),
        // Electrical Subject Sample
        SyllabusSubject(
            code = "66761",
            nameEn = "Alternating Current Machines - 2",
            nameBn = "অল্টারনেটিং কারেন্ট মেশিনস - ২",
            credits = 4,
            theoryHours = 3,
            practicalHours = 3,
            department = Department.ELECTRICAL,
            semester = 6,
            descriptionEn = "Synchronous motor working principle, alternator voltage regulation, 3-phase induction motor characteristics and speed control.",
            descriptionBn = "সিনক্রোনাস মোটর, অল্টারনেটর ভোল্টেজ রেগুলেশন, ৩-ফেজ ইনডাকশন মোটর ও পাওয়ার ড্রাইভ।",
            books = listOf("A Text Book of Electrical Technology by B.L. Theraja")
        )
    )

    val sampleLectureNotes = listOf(
        Triple(
            "ডাটাবেস নরমালাইজেশন (1NF to 3NF)",
            "নরমালাইজেশন হলো একটি রিলেশনাল ডাটাবেসে ডাটা রিডানড্যান্সি কমানো এবং ডাটা ইন্টিগ্রিটি বৃদ্ধি করার সুশৃঙ্খল পদ্ধতি।\n\n• 1NF: প্রতিটি কলামে অ্যাটমিক (অবিভাজ্য) মান থাকবে।\n• 2NF: 1NF শর্ত পূরণ করে সব নন-কী অ্যাট্রিবিউট সম্পূর্ণ প্রাইমারি কীর উপর নির্ভরশীল হবে।\n• 3NF: কোনো ট্রানজিটিভ ডিপেনডেন্সি (Transitive Dependency) থাকবে না।\n\nপরীক্ষায় ১০ নম্বরের ব্রড প্রশ্নে সাধারণত টেবিল দিয়ে 3NF এ রূপান্তর করতে আসে।",
            "66661 • Database"
        ),
        Triple(
            "মাইক্রোকন্ট্রোলার আর্কিটেকচার ও পিন কনফিগারেশন",
            "৮০৫১ (8051) হলো একটি ৮-বিট মাইক্রোকন্ট্রোলার যা ৪০টি পিনের DIP প্যাকেজে পাওয়া যায়।\n\nপ্রধান বৈশিষ্ট্যসমূহ:\n১. 4KB অন-চিপ রম (ROM)\n২. 128 Bytes অন-চিপ র‍্যাম (RAM)\n৩. ৪টি ৮-বিট প্যারালাল I/O পোর্টস (P0, P1, P2, P3)\n৪. ২টি ১৬-বিট টাইমার/কাউন্টার (T0, T1)\n৫. ৫টি ইন্টারাপ্ট সোর্স ও ফুল-ডুপ্লেক্স UART সিরিয়াল পোর্ট।",
            "66664 • Embedded"
        ),
        Triple(
            "সিজিটি ও ওহমের সূত্র সার্কিট এনালাইসিস",
            "সার্কিট থিওরেমস (Thevenin, Norton, Superposition):\n\nথেভেনিন থিওরেম অনুযায়ী, যেকোনো জটিল রৈখিক দুই-প্রান্তবিশিষ্ট ডিসি নেটওয়ার্ককে একটি সিঙ্গেল ভোল্টেজ সোর্স (Vth) এবং তার সাথে সিরিজে যুক্ত একটি রেজিস্ট্যান্স (Rth) দিয়ে প্রতিস্থাপন করা যায়।\n\nVth নির্ণয়: ওপেন সার্কিট ভোল্টেজ পরিমাপ করুন।\nRth নির্ণয়: সব ভোল্টেজ সোর্স শর্ট এবং কারেন্ট সোর্স ওপেন করে সমতুল্য রোধ বের করুন।",
            "66761 • Electrical"
        ),
        Triple(
            "সফটওয়্যার ডেভেলপমেন্ট লাইফ সাইকেল (SDLC)",
            "SDLC এর প্রধান ৬টি ধাপ:\n১. রিকোয়ারমেন্ট অ্যানালাইসিস (Requirement Gathering)\n২. সিস্টেম ডিজাইন ও আর্কিটেকচার (Design & Wireframe)\n৩. কোডিং ও ইমপ্লিমেন্টেশন (Development)\n৪. টেস্টিং ও ভ্যালিডেশন (QA & Bug Fix)\n৫. ডেপ্লয়মেন্ট ও প্রোডাকশন রিলিজ\n৬. মেইনটেন্যান্স ও আপগ্রেডেশন।",
            "66665 • Software Engg"
        )
    )

    // BTEB Probidhan Semester CGPA Weightage (1st to 8th)
    val btebWeightages = listOf(
        1 to 0.05, // 1st Semester: 5%
        2 to 0.05, // 2nd Semester: 5%
        3 to 0.05, // 3rd Semester: 5%
        4 to 0.10, // 4th Semester: 10%
        5 to 0.15, // 5th Semester: 15%
        6 to 0.20, // 6th Semester: 20%
        7 to 0.25, // 7th Semester: 25%
        8 to 0.15  // 8th Semester: 15% (Industrial Training)
    )

    val btebGradingScale = listOf(
        Triple("80% - 100%", "A+", "4.00"),
        Triple("75% - 79%", "A", "3.75"),
        Triple("70% - 74%", "A-", "3.50"),
        Triple("65% - 69%", "B+", "3.25"),
        Triple("60% - 64%", "B", "3.00"),
        Triple("55% - 59%", "B-", "2.75"),
        Triple("50% - 54%", "C+", "2.50"),
        Triple("45% - 49%", "C", "2.25"),
        Triple("40% - 44%", "D", "2.00"),
        Triple("0% - 39%", "F", "0.00 (Fail)")
    )
}
